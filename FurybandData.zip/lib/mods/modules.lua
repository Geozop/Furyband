-- Load ToME
tome_dofile_anywhere(ANGBAND_DIR, "module.lua")

-- Look for more modules
scan_extra_modules()
