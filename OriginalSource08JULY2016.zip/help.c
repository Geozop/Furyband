/* File: help.c */

/* Purpose: ingame help */
/*
 * Actually this is now handled by lua,
 * I'll remove this file when I feel un-lazy
 */

/*
 * Copyright (c) 2001 DarkGod
 *
 * This software may be copied and distributed for educational, research, and
 * not for profit purposes provided that this copyright and statement are
 * included in all such copies.
 */

#include "angband.h"

/*
 * Driver for the context-sensitive help system
 */
void ingame_help(bool enable)
{}
