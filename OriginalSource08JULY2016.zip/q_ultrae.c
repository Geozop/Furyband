/*
 * Here takes place the Evil ultra ending
 */

#undef cquest
#define cquest (quest[QUEST_ULTRA_EVIL])

bool quest_ultra_evil_init_hook(int q)
{
	return (FALSE);
}
